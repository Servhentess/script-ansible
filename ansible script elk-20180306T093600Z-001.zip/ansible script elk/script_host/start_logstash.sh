#!/bin/bash

/usr/share/logstash/bin/logstash -f /etc/logstash/conf.d/logstash-apache.conf